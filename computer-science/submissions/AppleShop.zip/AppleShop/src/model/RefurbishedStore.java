package model;

/*
 * Template of a collection of entries.
 */
public class RefurbishedStore {
	private Entry[] entries; // an array of Entry object references: each slot stores the reference of some Entry object
	/*
	 * Two purposes of this auxiliary counter:
	 * 1. records number of (non-null)entries have been stored in the 'entries' array
	 * 2. indicates the index of the entries array that will store the next new entry reference.
	 */
	private int noe;
	private final int MAX_CAPACITY = 5; // a constant maximum capacity
	
	public RefurbishedStore() {
		entries = new Entry[MAX_CAPACITY];
		noe = 0;
	}
	
	public int getNumberOfEntries() {
		return noe;
	}
	
	public Entry[] getPrivateEntriesArray() {
		return this.entries;
	}
	
	/*
	 * Retrieve the array of entries, arranged in the chronological order in which they were inserted.
	 * That is , the earlier an entry was inserted, the more front it appear in the return array
	 */
	public Entry[] getEntries() {
		Entry[] es = new Entry[noe];
		for (int i=0; i<noe; i++) {
			es[i] = entries[i];
		}
		return es;
	}
	
	// For now, assume serial number of input 'e' does not exist in the collection
	public void addEntry(Entry e) {
		entries[noe]=e;
		noe ++;
	}
	
	public void addEntry(String sn, Product p) {
//		Entry ne = new Entry(sn, p);
//		entries[noe]=ne;    	REPETITIVE JUST RECALL ORIGINAL - helper method
//		noe ++;
		this.addEntry(new Entry(sn, p));
	}
	
	public void addEntry(String sn, String model, double originalPrice) {
//		Product p = new Product(model, originalPrice);
//		Entry ne = new Entry(sn, p);
//		entries[noe]= ne;
//		noe ++;
		this.addEntry(new Entry(sn, new Product(model, originalPrice)));
	}
	
	public Product getProduct(String sn) {
		int index = -1; // expected to be reassigned to a valid index if he 'sn' exists in the store
		for (int i = 0; i< noe; i++) {
			Entry e = entries[i];
			if( e.getSerialNumber().equals(sn)){
				index = i;
			}
		}
		
		if (index<0) {
			return null;
		} 
		else {
			return entries[index].getProduct();	
		}
	}
	
	/*
	 * Return the serial numbers of all products that are 
	 * either Space Grey finish or is a pro
	 */
	public String[] getSpaceGreyOrPro() {
		int count = 0; //number of products satisfying the search criteria
		int[] indices = new int[noe]; //indices of entry objects in the entries array that satisfy the search criteria
		
		//step 1: collect all products satisfying the search criteria
		for (int i=0; i< noe; i++) {
			Product p = entries[i].getProduct();
			if (p.getModel().contains("Pro") || p.getFinish().equals("Space Grey")) {
				indices[count]=i;
				count++;
			}
		}
		//step 2: create array of strings (for serial numbers)
		String[] sns = new String[count];
		
		for (int i=0; i< count; i++) {
			sns[i] = entries[indices[i]].getSerialNumber();
		}
		
		return sns;
	}
	
	/*
	 * Return the serial numbers of all products that are 
	 * both Space Grey finish and is a pro
	 */
	public String[] getSpaceGreyAndPro() {
		int count = 0; //number of products satisfying the search criteria
		int[] indices = new int[noe]; //indices of entry objects in the entries array that satisfy the search criteria
		
		//step 1: collect all products satisfying the search criteria
		for (int i=0; i< noe; i++) {
			Product p = entries[i].getProduct();
			if (p.getModel().contains("Pro") && p.getFinish().equals("Space Grey")) {
				indices[count]=i;
				count++;
			}
		}
		//step 2: create array of strings (for serial numbers)
		String[] sns = new String[count];
		
		for (int i=0; i< count; i++) {
			sns[i] = entries[indices[i]].getSerialNumber();
		}
		
		return sns;
	}
	
}
