package model;
/*
 * Template of a unit of storage in the apple refurbished shop.
 * Think of a shop as a collection of entries. 
 */
public class Entry {
	//Attributes
	private String serialNumber; // Should be unique for each product 
	/*
	 * type of attribute is a reference type, denoting an existing class
	 * at runtime this attribute will store the address of some Product object
	 */
	private Product product; 
	
	//Constructor
	public Entry(String serialNumber, Product product) {
		this.serialNumber= serialNumber;
		this.product = product;
	}
	
	// Getter + Setters
	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	
	/*
	 * Overloaded version of the setProduct mutator
	 * This version of setProduct does not expect the user to create a 
	 * Product object and pass it as an argument.
	 * Instead expect the user to pass a String model and value of the original price.
	 * This method would create a new Product object accordingly
	 */
	
	public void setProduct(String model, double originalPrice) {
		this.product = new Product(model, originalPrice);
	}
	
	public String toString() {
		return "[" + serialNumber +  "] "+ product.toString();
	}
	
}
