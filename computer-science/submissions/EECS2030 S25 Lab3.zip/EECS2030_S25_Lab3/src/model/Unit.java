package model;

public class Unit {
	private String room;
	private int width;
	private int length;
	private String s;
	private double widthM;
	private double lengthM;
	private boolean toggle; //Let false be square feet, true be meters
	
	public Unit(String room, int width, int length) {
		this.room = room;
		this.width = width;
		this.length = length;
		this.toggle = false;
		this.s = "A unit of " + getArea() + " square feet (" + width + "' wide and " + length + "' long) functioning as " + room;
	}
	//copy constructor
	public Unit(Unit other) {
		this.room = other.room;
		this.width = other.width;
		this.length = other.length;
		this.toggle = other.toggle;
		this.s = other.s;
		this.widthM = other.widthM;
		this.lengthM = other.lengthM;
	}
	
	public int getArea() {
		return width*length;
	}
	public double getAreaM() {
		this.widthM = width*0.3048;
		this.lengthM = length*0.3048;
		return widthM*lengthM;
	}
	public String toString() {
		return s;
	}
	public void toggleMeasurement() {
		if (toggle == false) {
			this.toggle = true;
			this.s = "A unit of " + String.format("%.2f", getAreaM()) + " square meters (" + String.format("%.2f", widthM) + " m wide and " + String.format("%.2f", lengthM) + " m long) functioning as " + room;
		}
		else {
			this.toggle = false;
			this.s = "A unit of " + getArea() + " square feet (" + width + "' wide and " + length + "' long) functioning as " + room;
		}
	}
	public boolean equals(Object obj) {
		boolean result = false;
		Unit other = (Unit) obj;
		if (this == other) { return true;}
		if (other == null) {return result;}
		if ((this.room.equals(other.room)) && (this.getArea() == other.getArea())) {
			result= true;
		}
		return result;
	}
	public String shortString() {
		return room + ": " + getArea() + " sq ft (" + width + "' by " + length + "')";
	}
}
