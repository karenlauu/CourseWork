package model;

public class Floor {
	private int capacity;
	private int usedSpace;
	private String s;
	private Unit[] units;
	private int nou;
	
	public Floor(int ft) {
		this.capacity = ft;
		this.usedSpace = 0;
		this.s = "Floor's utilized space is " + usedSpace + " sq ft (" + capacity + " sq ft remaining): []";
		this.units = new Unit[20];
		this.nou = 0;
	}
	
	// copy constructor
	public Floor(Floor other) {
		this.nou = other.nou;
		this.capacity = other.capacity;
		this.usedSpace = other.usedSpace;
		this.s = other.s;
		this.units = new Unit[nou];
		for (int i=0; i<nou; i++) {
			this.units[i] = new Unit(other.units[i]);
		}
	}
	
	public void addUnit(String s, int i, int in) throws InsufficientFloorSpaceException{
		Unit u = new Unit(s, i, in);
		if (usedSpace + u.getArea() <= capacity) {
			units[nou] = u;
			nou ++;
			usedSpace += u.getArea();
			this.s = "Floor's utilized space is " + usedSpace + " sq ft (" + (capacity - usedSpace) + " sq ft remaining): " + getUnitString();
		} else {
			throw new InsufficientFloorSpaceException("Insufficient space");
		}
	}
	
	public String getUnitString() {
		String str = "[";
		for (int i=0; i<nou; i++) {
			str += units[i].shortString() + ", ";
		}
		str = str.substring(0, str.length()-2) + "]"; 
		return str;
	}
	
	public String toString() {
		return s;
	}
	public boolean compareFloors(Object obj) {
		Floor other = (Floor) obj;
		if (this.nou != other.nou) {return false;}
		int countUnique = 0;
		int[] floorCount1 = new int[nou];
		int[] floorCount2 = new int[nou];
		boolean[] checked = new boolean[nou]; //creates bool list to check if unit has already been counted
		
		for (int i=0; i<nou; i++) {
			if (checked[i]) continue; // if unit has been counted - skip
			
			Unit u = this.units[i];
			checked[i]=true;
			
			floorCount1[countUnique]++; 
			
			// for each floor check if each unit is 'equal' to the specific chosen unit
			for (int j = i + 1; j < nou; j++) {
	            if (!checked[j] && u.equals(this.units[j])) {
	                floorCount1[countUnique]++;
	                checked[j] = true;
	            }
	        }

	        for (int j = 0; j < nou; j++) {
	            if (u.equals(other.units[j])) {
	                floorCount2[countUnique]++;
	            }
	        }

	        countUnique++; // check for each unit
	    }
		// checks if unit count for each floor is the same - otherwise floors are not equal
		
		for (int i=0; i<countUnique; i++) {
			if (floorCount1[i] != floorCount2[i]) {
				return false;
			}
		}
		return true;
	}

	public boolean equals(Object obj) {
		Floor other = (Floor) obj;
		if (this == other) {return true;}
		if (other == null) {return false;}
		if (this.capacity == other.capacity && compareFloors(obj)) {
			return true;
		} else {
		return false;
		}
	}
}
