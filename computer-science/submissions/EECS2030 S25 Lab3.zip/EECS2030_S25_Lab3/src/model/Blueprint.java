package model;

public class Blueprint {
	private int maxFloors;
	private int numFloors;
	private String s;
	private Floor[] floors;
	
	public Blueprint(int max) {
		this.maxFloors= max;
		this.numFloors = 0;
		this.floors = new Floor[maxFloors];
		this.s = "0.0 percents of building blueprint completed (0 out of " + maxFloors +" floors)";
	}
	
	public Blueprint(Blueprint other) {
		this.maxFloors = other.maxFloors;
		this.numFloors = other.numFloors;
		this.s = other.s;
		this.floors = new Floor[numFloors];
		for (int i=0; i<numFloors; i++) {
			this.floors[i] = new Floor(other.floors[i]);
		}
	}
	
	public void addFloorPlan(Floor f) {
		floors[numFloors] = f;
		this.numFloors +=1;
		double completion = (double) numFloors/maxFloors;
		this.s = String.format("%.1f", completion*100) + " percents of building blueprint completed (" + numFloors + " out of " + maxFloors + " floors)";
	}
	public Floor[] getFloors() {
		Floor[] result = new Floor[numFloors];
		for (int i=0; i<numFloors; i++) {
			result[i] = new Floor(floors[i]);
		}
		
		return result;
	}
	public String toString() {
		return this.s;
	}
}
