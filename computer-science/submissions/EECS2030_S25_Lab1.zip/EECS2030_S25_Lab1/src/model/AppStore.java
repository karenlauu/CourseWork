package model;

public class AppStore {
	private String branchName;
	int numApps = 0;
	private App[] maxApps;
	
	public AppStore(String str, int num){
		this.maxApps= new App[num];
		this.branchName = str;
	}
	
	public String getBranch() {
		return branchName;
	}
	
	public void addApp(App apps) {
		maxApps[numApps] = apps;
		numApps++;
	}
	public App getApp(String name) {
		if (numApps > 0) {
			for (int i=0; i< numApps; i++) {
				if (maxApps[i].getName().equals(name)){
					return maxApps[i];
				}
			}
		} 
		return null;
	}
	public String[] getStableApps(int num) {
		App[] checkApps = new App[numApps];
		int numStable = 0;
		for (int i=0; i<numApps; i++) {
			if(maxApps[i].numUpdates >=num) {
				checkApps[numStable] = maxApps[i];
				numStable++;
			}
		}
		
		String[] result = new String[numStable];
		for (int i=0; i<numStable; i++) {
			String s = ""+ checkApps[i].getName() + " (" + checkApps[i].numUpdates + " versions; ";
			s += "Current Version: " + checkApps[i].getUpdateHistory()[checkApps[i].numUpdates-1].toString() + ")";
			result[i] = s;
		}
		return result;
	}
}

