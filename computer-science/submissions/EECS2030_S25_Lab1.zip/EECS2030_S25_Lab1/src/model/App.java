package model;

public class App {
	String name = "";
	int max_ratings = 0;
	Log[] maxHistory = new Log[20];
	int numUpdates = 0;
	int[] ratings;
	int numRate = 0;
	
	public App(String name, int num) {
		this.name = name;
		this.max_ratings=num;
		this.ratings = new int[max_ratings];
	}
	public String getName() {
		return name;
	}
	public String getWhatIsNew() {
		if (numUpdates>0) {
			return maxHistory[numUpdates -1].toString();
		} else 
			return "n/a";
	}
	public Log[] getUpdateHistory() {
		Log[] updateHistory = new Log[numUpdates];
		for (int i=0; i<numUpdates;i++) {
			updateHistory[i] = maxHistory[i];
		}
		return updateHistory;
	}
	public void releaseUpdate(String str) {
		maxHistory[numUpdates] = new Log(str);
		numUpdates++;
	}
	public Log getVersionInfo(String str) {
		if (numUpdates>0) {
			for (int i = 0; i<numUpdates; i++) {
				String check = maxHistory[i].getVersion();
				if (check.equals(str)) {
					return maxHistory[i];
				}
			}
		}return null;
	}
	
	public void submitRating(int rate) {
		ratings[numRate]=rate;
		numRate++;
	}
	
	public String averageRate() {
		int sum = 0;
		if (numRate>0) {
			for (int i=0; i<numRate;i++) {
				sum += ratings[i];
			}
		return String.format("%.1f", (double) sum / numRate);
		}
		return "n/a";
		
	}
	public int ratecount(int rate) {
		int[] count = new int[5];
		for (int i=0; i<numRate; i++) {
			if (ratings[i] == 5) {
				count[4]++;
			} else if (ratings[i]==4) {
				count[3]++;
			} else if (ratings[i]==3) {
				count[2]++;
			} else if (ratings[i]==2) {
				count[1]++;
			} else if (ratings[i]==1) {
				count[0]++;
			}
		}
		return count[rate-1];
	}
	public String getRatingReport() {
		
		String s = "";
		if (numRate == 0) {
			s += "No ratings submitted so far!";
		} else {
		s += "Average of " + numRate + " ratings: " + averageRate() +  " (Score 5: ";
		s += ratecount(5) + ", Score 4: " + ratecount(4) + ", Score 3: " + ratecount(3);
		s+= ", Score 2: " + ratecount(2) + ", Score 1: " + ratecount(1) + ")";
		}
		return s;
	}
	public String toString() {
		String s = "";
		s += name + " (Current Version: " + getWhatIsNew() + "; Average Rating: " + averageRate() + ")";
		return s; 
	}
}
