package model;

public class Log {
	String version = "";
	String[] logFix = new String[10];
	private int nof = 0;
	
	public Log(String str) {
		this.version = str;
	}
	
	public void addFix(String str) {
		logFix[nof]= str;
		nof++;
	}
	public String getVersion() {
		return version;
	}
	public int getNumberOfFixes() {
		return nof;
	}
	public String getFixes() {
		String s = "[";
		if (nof==0) {
			s += "]";
		} else if (nof==1) {
			s+= logFix[0]+ "]";
		}
		else {
			for (int i=0; i<nof-1; i++) {
				s += logFix[i] + ", ";
			}
			s += logFix[nof-1] + "]";
		}
		return s;
	}
	public String toString() {
		String s = "";
		s+= "Version " + version + " contains " + getNumberOfFixes() + " fixes " + getFixes();
		return s;
	}
	
}
