package model;

public class Account {
	private String name;
	private AppStore linkedStore;
	private int numDownload;
	private App[] maxDownload;
	private App[] downloaded;
	private String lastMutator;
	
	public Account(String name, AppStore linked) {
		this.name = name;
		this.linkedStore = linked;
		this.maxDownload = new App[50];
		this.numDownload=0;
		lastMutator = "An account linked to the " +  linked.getBranch()+ " store is created for " + name +  ".";
	}
	
	public String[] getNamesOfDownloadedApps() {
		String[] result = new String[numDownload];
		for (int i=0; i< numDownload; i++) {
			result[i]= maxDownload[i].getName();
		}
		return result;
	}
	public App[] getObjectsOfDownloadedApps() {
		downloaded = new App[numDownload];
		for (int i = 0; i< numDownload; i++) {
			downloaded[i] = maxDownload[i];
		}
		return downloaded;
	}
	
	public void uninstall(String appName) {
		if (numDownload == 0) {
			lastMutator = "Error: " + appName + " has not been downloaded for " + name + ".";
			return;
		}
		for (int i=0; i< numDownload; i++) {
			if (maxDownload[i].getName().equals(appName)){
				for (int j = i; j< numDownload-1; j++) {
					maxDownload[j]=maxDownload[j+1];
				}
				maxDownload[numDownload - 1] = null; 
				numDownload--;

				lastMutator = appName +  " is successfully uninstalled for " + name +".";
				return;
			}
		}
		lastMutator = "Error: " + appName + " has not been downloaded for " + name + ".";
	}

	
	public void submitRating(String appName, int rate) {
		for (int i=0; i< numDownload; i++) {
			if (maxDownload[i].getName().equals(appName)) {
				maxDownload[i].submitRating(rate);
				lastMutator = "Rating score " + rate + " of " + name + " is successfully submitted for " + appName + ".";
				return;
			} 
		}lastMutator = "Error: " + appName+ " is not a downloaded app for " + name + ".";
	}
	
	public void switchStore(AppStore appStore) {
		this.linkedStore = appStore;
		lastMutator = "Account for " + name + " is now linked to the " + appStore.getBranch() + " store.";
	}
	
	public void download(String appName) {
		for (int i=0; i<numDownload; i++) {
			if (maxDownload[i].getName().equals(appName)) {
				lastMutator = "Error: " + appName+ " has already been downloaded for "+name + ".";
				return;
			}
		}
		
		maxDownload[numDownload] = linkedStore.getApp(appName);
		numDownload ++;
		lastMutator = appName + " is successfully downloaded for " + name + ".";
	}
	public String toString() {
		return lastMutator;
	}
}
