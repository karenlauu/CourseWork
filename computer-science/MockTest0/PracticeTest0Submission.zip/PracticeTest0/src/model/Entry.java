package model;

public class Entry {
	String serialNumber;
	Product product;
	
	
	public Entry(String sn, Product p) {
		this.serialNumber=sn;
		this.product = p;
	}


	public String getSerialNumber() {
		return serialNumber;
	}


	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}


	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}
	public void setProduct(String str, double op) {
		this.product = new Product(str, op);
	}
	public String toString() {
		String s = "[" + serialNumber + "] ";
		s += product.toString();
		return s;
	}
}
