package model;

public class RefurbishedStore {
	private int numberOfEntries = 0;
	private final int MAX_CAPACITY =5;
	private Entry[] privateEntriesArray = new Entry[MAX_CAPACITY];
	
	public RefurbishedStore() {
	}

	public int getNumberOfEntries() {
		return numberOfEntries;
	}

	public void setNumberOfEntries(int numberOfEntries) {
		this.numberOfEntries = numberOfEntries;
	}

	public Entry[] getPrivateEntriesArray() {
		return privateEntriesArray;
	}

	public void setPrivateEntriesArray(Entry[] privateEntriesArray) {
		this.privateEntriesArray = privateEntriesArray;
	}

	public Entry[] getEntries() {
		Entry[] entry = new Entry[numberOfEntries];
		for (int i = 0; i<numberOfEntries; i++) {
			entry[i] = privateEntriesArray[i];
		}
		return entry;
	}
	
	public void addEntry(Entry e1) {
		privateEntriesArray[numberOfEntries] = e1;
		numberOfEntries++;
	}
	public void addEntry(String s, Product p) {
		privateEntriesArray[numberOfEntries] = new Entry(s, p);
		numberOfEntries++;
	}
	public void addEntry(String s, String m, double op) {
		privateEntriesArray[numberOfEntries] = new Entry(s, new Product(m, op));
		numberOfEntries++;
	}
	public Product getProduct(String str) {
		for (int i = 0; i<numberOfEntries; i++) {
			if (privateEntriesArray[i].getSerialNumber().equals(str)) {
				return privateEntriesArray[i].getProduct();
			}
		}return null;
	}
	public String[] getSpaceGreyOrPro() {
		Entry[] checkStock = new Entry[numberOfEntries];
		int numStock = 0;
		for (int i = 0; i<numberOfEntries; i++) {
			Product prod = privateEntriesArray[i].getProduct();
			if ((prod.getFinish().equals("Space Grey"))|| (prod.getModel().contains("Pro"))){
				checkStock[numStock]= privateEntriesArray[i];
				numStock++;
			}
		}
		
		String[] result = new String[numStock];
		for (int i =0; i<numStock; i++) {
			result[i] = checkStock[i].getSerialNumber();
		}
		return result;
	}
	public String[] getSpaceGreyPro() {
		Entry[] checkStock = new Entry[numberOfEntries];
		int numStock = 0;
		for (int i = 0; i<numberOfEntries; i++) {
			Product prod = privateEntriesArray[i].getProduct();
			if ((prod.getFinish().equals("Space Grey")) && (prod.getModel().contains("Pro"))){
				checkStock[numStock]= privateEntriesArray[i];
				numStock++;
			}
		}
		
		String[] result = new String[numStock];
		for (int i =0; i<numStock; i++) {
			result[i] = checkStock[i].getSerialNumber();
		}
		return result;
	}
}
