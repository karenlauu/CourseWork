package model;

public class VaccineDistribution {
	private Vaccine vaccine;
	private int doses;
	
	public VaccineDistribution(Vaccine v, int doses) {
	this.vaccine = v;
	this.doses = doses;
	}
	public String toString() {
		String s = doses + " doses of " + vaccine.getCodename() + " by " + vaccine.getManufacturer();
		return s;
	}
}
