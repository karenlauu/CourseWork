package model;

public class HealthRecord {
	private String name;
	private String[] records;
	private int nov;
	private VaccinationSite appointment;
	private boolean appointmentStatus;
	
	public HealthRecord(String patient, int limit) {
		this.name = patient;
		this.records = new String[limit];
		this.nov=0;
		this.appointmentStatus=true;
	}
	
	public String getVaccinationReceipt() {
		String s = name + " has not yet received any doses.";
		
		if (nov>0) {
			s = "Number of doses " + name + " has received: " + nov + " [";
			for (int i =0; i<nov; i++) {
				s += records[i] +  "; ";
			}
			s = s.substring(0, s.length()-2) + "]";
		}
		
		return s;
	}
	public void setAppointment(VaccinationSite s) {
		this.appointment = s;
	}
	public void setAppointmentStatus(boolean b) {
		this.appointmentStatus = b;
	}
	public String getAppointmentStatus() {
		String s = "No vaccination appointment for " + name + " yet";
		if (appointment != null && appointmentStatus == true) {
			s = "Last vaccination appointment for " + name + " with " + appointment.getSite() +" succeeded";
		} else if (appointment != null && appointmentStatus == false) {
			s = "Last vaccination appointment for " + name + " with " + appointment.getSite() +" failed";
		}
		return s;
	}
	public void addRecord(Vaccine v, String site, String date) {
		records[nov] = v.toString() + " in " + site + " on " + date;
		nov++;
	}
}
