package model;

public class Vaccine {
	private String codename;
	private String type;
	private String manufacturer;
	
	public Vaccine(String str, String str2, String str3) {
		this.codename = str;
		this.type = str2;
		this.manufacturer= str3;
	}
	public String getCodename() {
		return codename;
	}
	public String getType() {
		return type;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public String canadianVaccine(String code) {
		String result = "Unrecognized vaccine";
		if ((code.equals("mRNA-1273")) || (code.equals("BNT162b2")) || (code.equals("Ad26.COV2.S")) || (code.equals("AZD1222"))){
			result = "Recognized vaccine";
		}return result;
	}
	
	public String toString() {
		String s = canadianVaccine(codename) + ": " + codename + " (" + type + "; " + manufacturer + ")";
		return s;
	}
}
