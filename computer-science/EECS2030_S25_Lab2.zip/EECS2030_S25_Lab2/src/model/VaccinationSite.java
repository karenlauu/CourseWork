package model;

public class VaccinationSite {
	private String site;
	private int[] storage;
	private int totalDoses;
	private Vaccine[] supply;
	private HealthRecord[] appointments;
	private int noa;
	private int limit;
	private Vaccine[] order;
	
	public VaccinationSite(String site, int limit) {
		this.site = site;
		this.storage = new int[4];
		this.totalDoses=0;
		this.supply = new Vaccine[limit];
		this.appointments = new HealthRecord[200];
		this.noa = 0;
		this.limit = limit;
		this.order = new Vaccine[0];
	}
	public String getSite() {
		return site;
	}
	
	public int getNumberOfAvailableDoses() {
		return totalDoses;
	}
	public int getNumberOfAvailableDoses(String code) {
		int result = 0;
		if (code.equals("mRNA-1273")) {
			result = storage[0];
		} else if (code.equals("BNT162b2")) {
			result = storage[1];
		}else if (code.equals("Ad26.COV2.S")) {
			result = storage[2];
		} else if (code.equals("AZD1222")) {
			result = storage[3];
		}		
		return result;
	}
	public void addDistribution(Vaccine v, int doses) throws UnrecognizedVaccineCodeNameException, TooMuchDistributionException {
		if (v.getCodename().equals("mRNA-1273")) {
			storage[0] += doses;
		} else if (v.getCodename().equals("BNT162b2")) {
			storage[1] += doses;
		}else if (v.getCodename().equals("Ad26.COV2.S")) {
			storage[2] += doses;
		} else if (v.getCodename().equals("AZD1222")) {
			storage[3] += doses;
		} else {
			throw new UnrecognizedVaccineCodeNameException("Unknown vaccine");
		}
		
		if (totalDoses + doses > limit) {
			throw new TooMuchDistributionException("Exceeds site limit");
		}
		for (int i=0; i<doses; i++) {
			supply[totalDoses] = v;
			totalDoses++;
			if (totalDoses > limit) {
				throw new TooMuchDistributionException("Exceeds site limit");
			}
		}
		this.order = getOrder();
	}
	
//	public String toString() {
//		String s = site + " has " + totalDoses + " available doses: <";
//		if (totalDoses !=0) {
//			if (storage[3] != 0) {
//				s += storage[3] + " doses of Oxford/AstraZeneca, ";
//			} if (storage[0] != 0) {
//				s += storage[0] + " doses of Moderna, ";
//			}if (storage[1] != 0) {
//				s += storage[1] + " doses of Pfizer/BioNTech, ";
//			}if (storage[2] != 0) {
//				s += storage[2] + " doses of Janssen, ";
//			}
//			s = s.substring(0, s.length()-2);
//		}
//		s += ">";
//		return s;
//	}
	public Vaccine[] getOrder() {
		int numBrands=0;
		Vaccine[] order = new Vaccine[4];
		
		for (int i=0; i<supply.length && supply[i] != null; i++) {
			boolean added = false;
			
			for (int j=0; j< numBrands; j++ ) {
				if (order[j].equals(supply[i])) {
					added = true;
					break;
				}	
			}
			if (!added) {
				order[numBrands] = supply[i];
				numBrands++;
			}
		}
		Vaccine[] order1 = new Vaccine[numBrands];
		for (int i=0; i<numBrands; i++) {
			order1[i] = order[i];
		}
		return order1; 
	}
	
	public String toString() {
		String s = site + " has " + totalDoses + " available doses: <";
		boolean added = order.length > 0;
		
		if (totalDoses !=0 || added) {
			Vaccine[] v = order;
			for (int i=0; i<v.length; i++) {
				s += getNumberOfAvailableDoses(v[i].getCodename()) + " doses of " + v[i].getManufacturer() +", ";
			}
			s = s.substring(0, s.length()-2);
		}
		s += ">";
		return s;
	}
	
	
	public void bookAppointment(HealthRecord h) throws InsufficientVaccineDosesException {
		h.setAppointment(this);
		appointments[noa] = h;
		noa++;
		if (totalDoses < noa) {
			h.setAppointmentStatus(false);
			throw new InsufficientVaccineDosesException("Insufficient Doses");
		}
	}
	public void usedDose(Vaccine v) {
		for (int i=0; i< totalDoses; i++) {
			if(supply[i].equals(v)) {
				for (int j=i; j< totalDoses-1; j++) {
					supply[j] = supply[j+1];
				}
				totalDoses--;
				break;
			}
		}
	}

	public void administer(String date) {
		int appointmentIndex = 0;
		for (int i = 0; i< order.length && appointmentIndex < noa; i ++) {
			Vaccine current = order[i];
			for (int j=0; j< totalDoses && appointmentIndex < noa; j++) {
				if (getNumberOfAvailableDoses(current.getCodename())!=0) {
					HealthRecord h = appointments[appointmentIndex];
					h.addRecord(current, site, date);
					
					String code = current.getCodename();
					if (code.equals("mRNA-1273")) {
				        storage[0]--;
				    } else if (code.equals("BNT162b2")) {
				        storage[1]--;
				    } else if (code.equals("Ad26.COV2.S")) {
				        storage[2]--;
				    } else if (code.equals("AZD1222")) {
				        storage[3]--;
				    }
					usedDose(current);
					appointmentIndex++;
				}
			}
		}
		
		for (int i=0; i<noa; i++) {
			appointments[i] = null;
		}
	    noa=0; 
	}
}
