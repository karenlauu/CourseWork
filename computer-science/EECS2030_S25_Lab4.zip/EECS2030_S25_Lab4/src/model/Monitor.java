package model;

public class Monitor extends Follower {
	boolean mon;
	String status;
	
	public Monitor(String name, int num){
		super(name, num);
		this.mon = false;
	}
	
	public String toString() {
		String result = super.toString() + ".";
		if (mon) {
			result = this.status;
			mon = false;
		}
		return result;
	}
	
	public String getName() {
		return "Monitor " + super.getName();
	}
	
	public void updateStatus(String s) {
		this.status = s;
		this.mon = true;
	}
}
