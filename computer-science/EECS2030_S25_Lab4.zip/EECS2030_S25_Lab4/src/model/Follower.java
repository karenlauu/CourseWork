package model;

public class Follower {
	String name;
	int numFollow;
	Channel[] followList;
	
	public Follower(String name, int num){	
		this.name=name;
		this.numFollow = 0;
		this.followList = new Channel[num];
	}
	
	public String toString() {
		String result = String.format("%s follows no channels", getName());
		if (numFollow>0) {
			result = String.format("%s follows [%s]", getName(), toList());
		}
		return result;
	}
	
	public String toList() {
		String result = "";
		for (int i=0; i<numFollow; i++) {
			result += followList[i].getName() ;
			if (i< numFollow - 1) {
				result += ", ";
			}
		}
		return result;
	}
	
	public String getName() {
		return name;
	}
	
	public void follow(Channel c) {
		followList[numFollow] = c;
		numFollow++;
	}
	
	public void unfollow(Channel c) {
		int index = checkChannel(c);
		for (int i=index; i< numFollow-1; i++) {
			followList[i] = followList[i+1];
		}
		numFollow --;
	}
	
	public int checkChannel(Channel c) {
		int index = -1;
		for (int i = 0; i<numFollow; i++) {
			if (c.equals(followList[i])) {
				index = i;
			}
		} return index;
	}
	
	public void recommend(String s) {
		
	}
	
	public Channel findChannel(String s) {
		int result = -1;
		for (int i = 0; i<numFollow; i++) {
			Channel c = followList[i];
			if (c.checkVideo(s) != -1) {
				result = i;
			}
		} return followList[result];
	}
	
	public void updateStatus(String s) {
		
	}
}
