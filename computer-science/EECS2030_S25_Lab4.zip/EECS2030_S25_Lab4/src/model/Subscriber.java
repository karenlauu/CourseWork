package model;

public class Subscriber extends Follower {
	int numRec;
	String[] recs;
	
	public Subscriber(String name, int num, int numm){
		super(name, num);
		this.recs = new String[numm];
	}
	
	public String toVList() {
		String result = "";
		for (int i=0; i<numRec; i++) {
			result += recs[i];
			if (i< numRec-1) {
				result += ", ";
			}
		}
		return result;
	}
	
	public String toString() {
		String result = super.toString() + " and has no recommended videos.";
		if (numRec>0) {
			result = super.toString() + String.format(" and is recommended <%s>.", toVList());
		}
		return  result;
	}
	
	public String getName() {
		return "Subscriber " + super.getName();
	}
	
	public void recommend(String s) {
		recs[numRec] = s;
		this.numRec++;
	}
	
	public void watch(String s, int min) {
		Channel c = super.findChannel(s);
		
	}
}
