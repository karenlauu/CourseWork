package model;

public class Channel {
	private String[] videos;
	private int followerCount;
	private String name;
	private Follower[] followers;
	private int numVid;
	private int[] views;
	

	public Channel(String str, int follow, int vid) {
		this.name = str;
		this.videos = new String[vid];
		this.followerCount = 0;
		this.numVid = 0;
		this.followers = new Follower[follow];
		this.views = new int[vid];
	}
	
	public void releaseANewVideo(String str) {
		videos[numVid] = str;
		numVid++;
		for (int i = 0; i<followerCount; i++) {
			followers[i].recommend(str);
		}
	}
	
	public String strVlist() {
		String result = "";
		for (int i =0; i<numVid; i++) {	
			result += videos[i] + ", ";
		}
		result = result.substring(0, result.length()-2);
		return result;
	}
	
	public String strFlist() {
		String result = "";
		for (int i =0; i<followerCount; i++) {	
			result += followers[i].getName() + ", ";
		}
		result = result.substring(0, result.length()-2);
		return result;
	}
	
	public String toString() {
		String result = String.format("%s released no videos and has no followers.", getName());
		if (this.numVid>0 && followerCount == 0) {
			result = String.format("%s released <%s> and has no followers.",  getName(), strVlist());
		}
		if (this.numVid==0 && followerCount>0) {
			result = String.format("%s released no videos and is followed by [%s].",  getName(), strFlist());
		}
		if (this.numVid>0 && followerCount >0) {
			result = String.format("%s released <%s> and is followed by [%s].",  getName(), strVlist(), strFlist());
		}
		return result;
	}
	
	
	public void follow(Follower f) {
		followers[followerCount] = f;
		followerCount++;
		f.follow(this);
		
	}
	public String getName() {
		return name;
	}
	
	public void unfollow(Follower f) {
		int index = checkFollowers(f);
		if (index != -1) {
			for (int i=index; i< followerCount-1; i++) {
				followers[i] = followers[i+1];
			}
			followerCount --;
			f.unfollow(this);
		}
	}
	
	public int checkFollowers(Follower f) {
		int index = -1;
		for (int i = 0; i<followerCount; i++) {
			if (f.getName().equals(followers[i].getName())) {
				index = i;
			}
		} return index;
	}
	
	public int checkVideo(String s) {
		int result = -1;
		for (int i = 0; i<numVid; i++) {
			if (s.equals(videos[i])) {
				result = i;
			}
		} return result;
	}
	
//	public void updateF(String str, int num) {
//		int index = checkVideo(str) ;
//		if (index!= -1) {
//			views[index] ++;
//		}
//		String s  = String.format("{#views: %d, max watch time: %d, avg watch time: %.2f}", views[index], 20, 20);
//		for (int i=0; i<followerCount; i++) {
//			followers[i].updateStatus(s);
//		}
//	}
}
	
